<?php
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    $id_A = isset($_GET["ID_Encheres"])? $_GET["ID_Encheres"] : "";
    $PrixEnchere = isset($_POST["PrixEnchere"])? $_POST["PrixEnchere"] : "";

    
    $database = "ece_marketplace" ;

    
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;

    $sql = "SELECT * FROM encheres WHERE ID_Articles= '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data_enchere = mysqli_fetch_assoc($result);
    $tmp = $data_enchere['PrixMax'];

    if($data_enchere['PrixMax'] != 0) {
        if($PrixEnchere > $data_enchere['PrixMax']) {
            $sql = "UPDATE encheres SET Email_Acheteur = '" . $_SESSION['Email_Acheteur'] . "' WHERE ID_Articles = '$id_A'";
            $result = mysqli_query($db_handle, $sql);
            
            $sql = "UPDATE encheres SET PrixMax = '$PrixEnchere' WHERE ID_Articles = '$id_A'";
            $result = mysqli_query($db_handle, $sql);
            
            $sql = "UPDATE encheres SET PrixFin = '$tmp' WHERE ID_Articles= '$id_A'";
            $result = mysqli_query($db_handle, $sql);
        }
        if($PrixEnchere < $data_enchere['PrixMax'] && $PrixEnchere > $data_enchere['PrixFin']) {
            $sql = "UPDATE encheres SET PrixFin = '$PrixEnchere' WHERE ID_Articles = '$id_A'";
            $result = mysqli_query($db_handle, $sql);
        }
    }
    else {
        $sql = "UPDATE encheres SET Email_Acheteur = '" . $_SESSION['Email_Acheteur'] . "' WHERE ID_Articles = '$id_A'";
        $result = mysqli_query($db_handle, $sql);
        $sql = "UPDATE encheres SET PrixMax = '$PrixEnchere' WHERE ID_Articles= '$id_A'";
        $result = mysqli_query($db_handle, $sql);
        $sql = "UPDATE encheres SET PrixFin = '$PrixEnchere' WHERE ID_Articles= '$id_A'";
        $result = mysqli_query($db_handle, $sql);
    }

    header('Location: TypeAchatMeilleureO.php');
?>