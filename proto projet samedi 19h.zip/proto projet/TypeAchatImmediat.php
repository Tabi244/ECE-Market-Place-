<?php 
    session_start();

    header( 'content-type: text/html; charset=utf-8' );

    $database = "ece_marketplace" ;
    
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;

    $sql_article= "SELECT * FROM articles WHERE TypeAchat LIKE '%achat direct%'" ;
    $result_article= mysqli_query($db_handle, $sql_article);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="page_bienvenue.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}
		
        .card-img-top {
            width: 350px;
            height: 200px;
            background-position: center center;
        }
		

</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1><br><br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>         
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
<br><br>

</header>
	
	
    <div id="contenu">
        <div class="container">
<?php
                while ($data_article = mysqli_fetch_assoc($result_article)) {
?>
            <div class="row border d-flex align-items-center">
                
                <div class="col-lg-6 col-md-6">
                    <ul class="puce">
                        <li><strong><?php echo $data_article['Nom_article']; ?></strong></li>
                        <br />
                        <li>Catégorie : <?php echo $data_article['Categorie']; ?></li>
                        <li>Type d'achat : <?php echo $data_article['TypeAchat']; ?></li>
                        <br />
                        <li><?php echo number_format($data_article['Prix'], 2, ',', ' '); ?>€</li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2">
                    
					 
					<form method="post" action="paiement_a.php?ID_Articles=<?php echo $data_article['ID_Articles']; ?>">
                        <button type="submit" class="btn btn-info" name="btn_infos">Acheter</button>
                    </form>
                </div>
            </div>
<?php
                echo "<br /><br /><br />";
                }
?>
</div>
<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur    </a> <a href="Connexion_vendeur.php">     Vendeur</a></h6>

</div>
</body>

</html>