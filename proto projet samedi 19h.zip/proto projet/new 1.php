<?php
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    
    $id_A = isset($_GET["ID_Articles"])? $_GET["ID_Articles"] : "";
    $a = isset($_GET["a"])? $_GET["a"] : "";
    $prix_total = 0;
//Permet de récupération les données
    $database = "ece_marketplace" ;
    //bdd = ece_marketplace
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "SELECT * FROM articles WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data_article = mysqli_fetch_assoc($result);
    
    $Email_Vendeur = $data_article['Email_vendeur'];
    $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
    $result = mysqli_query($db_handle, $sql);
    $data_vendeur = mysqli_fetch_assoc($result);


    //Panier Achats Immédiat
    if(!isset($_SESSION['Panier_AI'])) {
		$_SESSION['Panier_AI'] = array();
    }
    //Panier Négo
    if(!isset($_SESSION['Panier_NE'])) {
		$_SESSION['Panier_NE'] = array();
    }
    //Panier Enchères
    if(!isset($_SESSION['Panier_E'])) {
		$_SESSION['Panier_E'] = array();
    }
	array_push($_SESSION['Panier_AI'], $id_A);

	 if(isset($_POST['negociation_validé'])) {
        array_push($_SESSION['Panier_NE'], $id_A);
    }
    //Le bouton negotion validé enclenché 
    if(isset($_POST['enchere'])) {
        array_push($_SESSION['Panier_E'], $id_A);
    }
    //bouton enchere enclenché


    //Supprimer AI

    if($a == 1) {
        unset($_SESSION['Panier_AI'][array_search($data_article['ID_Articles'], $_SESSION['Panier_AI'])]);
    }
    //Supprimer NE 
    if($a == 2) {
        unset($_SESSION['Panier_NE'][array_search($data_article['ID_Articles'], $_SESSION['Panier_NE'])]);
    }
    //Supprimer E
    if($a == 3) {
        unset($_SESSION['Panier_E'][array_search($data_article['ID_Articles'], $_SESSION['Panier_E'])]);
    }
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>

	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}

</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  
		<a href="index.php">
			<img src="images/eceMarketPlaceLogo.png" style="width:70px"/>
		</a>
	</h1>
	</br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages_acheteur.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>         
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
</br></br>

</header>
<body>

<!--
	<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">Open modal for @mdo</button>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@fat">Open modal for @fat</button>
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@getbootstrap">Open modal for @getbootstrap</button>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form>
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Recipient:</label>
            <input type="text" class="form-control" id="recipient-name">
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Message:</label>
            <textarea class="form-control" id="message-text"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Send message</button>
      </div>
    </div>
  </div>
</div>
-->

</br>


<div id="contenu">
        <div class="container">
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-12 text-center"></div>
                <div class="col-lg-10 col-md-10 col-sm-12 text-center">
<?php
            if(count($_SESSION['Panier_AI']) === 0 && count($_SESSION['Panier_NE']) === 0 && count($_SESSION['Panier_E']) === 0) {
                echo "<h1 class='text-center'>Votre Panier ne comporte aucun article!</h1>";
            }
            else {
?>
                    <table class='table table-hover table-responsive-sm'>
                        <thead>
                            <tr>
                                <th align='center'>Libellé</th>
                                <th align='center'>Vendeur</th>
                                <th align='center'>Quantité</th>
                                <th align='center'>Prix</th>
                                <th style='text-align: center'>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                if(!empty($_SESSION['Panier_AI'])) {
                    foreach($_SESSION['Panier_AI'] as $element_AI) {
                        $sql = "SELECT * FROM articles WHERE ID_Articles = '$element_AI'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_article = mysqli_fetch_assoc($result);
    
                        $Email_Vendeur = $data_article['Email_vendeur'];
                        $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_vendeur = mysqli_fetch_assoc($result);
                    
                        $prix_total += $data_article['Prix'];
?>
                            <tr>
                                <td><?php echo $data_article['Nom_article']; ?></td>
                                <td><?php echo $data_vendeur['Email_vendeur']; ?></td>
                                <td>1</td>
                                <td><?php echo number_format($data_article['Prix'], 2, ',', ' '); ?>€</td>
                                <td align='center'>
                                    <div class='btn-group btn-group-sm'>
                                        <a class="btn btn-danger" href="panier_acheteur.php?id_article=<?php echo $data_article['ID_Articles']; ?>&amp;a=1">Supprimer</a>
                                        

                                    </div>
                                </td>
                            </tr>
<?php
                    }
                    unset($element_AI);
                }
                
                if(!empty($_SESSION['Panier_NE'])) {
                    foreach($_SESSION['Panier_NE'] as $element_NE) {
                        $sql = "SELECT * FROM articles WHERE ID_Articles = '$element_NE'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_article = mysqli_fetch_assoc($result);
    
                        $Email_Vendeur = $data_article['Email_vendeur'];
                        $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_vendeur = mysqli_fetch_assoc($result); //Nom du Vendeur
                    
                        $sql = "SELECT * FROM negociation WHERE ID_MeilleurOffre= '$id_A'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_ne = mysqli_fetch_assoc($result);
                    
                        $prix_total += $data_ne['PrixNegocie'];
?>
                            <tr>
                                <td><?php echo $data_article['Nom_article']; ?></td>
                                <td><?php echo $data_vendeur['Email_vendeur']; ?></td>
                                <td>1</td>
                                <td><?php echo number_format($data_ne['PrixNegocie'], 2, ',', ' '); ?>€</td>
                                <td align='center'>
                                    <div class='btn-group btn-group-sm'>
                                        
                                        <a class="btn btn-danger" href="panier_acheteur.php?id_article=<?php echo $data_article['ID_Articles']; ?>&amp;a=2">Supprimer</a>
                                        

                                    </div>
                                </td>
                            </tr>
<?php
                    }
                    unset($element_NE);
                }
                
                if(!empty($_SESSION['Panier_E'])) {
                    foreach($_SESSION['Panier_E'] as $element_E) {
                        $sql = "SELECT * FROM articles WHERE ID_Articles = '$element_E'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_article = mysqli_fetch_assoc($result);
    
                        $Email_Vendeur = $data_article['Email_vendeur'];
                        $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_vendeur = mysqli_fetch_assoc($result); 
                    
                        $sql = "SELECT * FROM encheres WHERE ID_Articles = '$id_A'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_Encheres = mysqli_fetch_assoc($result);
                    
                        $prix_total += ($data_E['PrixFin'] + 1);
?>
                            <tr>
                                <td><?php echo $data_article['Nom_article']; ?></td>
                                <td><?php echo $data_vendeur['Email_vendeur']; ?></td>
                                <td>1</td>
                                <td><?php echo number_format($data_E['PrixFin'] + 1, 2, ',', ' '); ?>€</td>
                                <td align='center'>
                                    <div class='btn-group btn-group-sm'>
                                        <a class="btn btn-danger" href="panier_acheteur.php?id_article=<?php echo $data_article['ID_Articles']; ?>&amp;a=3">Supprimer</a>
                                        

                                    </div>
                                </td>
                            </tr>
<?php
                    }
                    unset($element_E);
                }
?>
                            <tr>
                                <td></td>
                                <td></td>
                                <td class='bg-info'>Total de votre commande:</td>
                                <td class='bg-info'><?php echo number_format($prix_total, 2, ',', ' '); ?>€</td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
            </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 d-flex justify-content-center">
                <button type='button' class='btn btn-success'>Commander</button>
            </a>
        </div>
    </div>

<?php
            }
?>
    <footer>
        <div class="container-fluid">
            <p class="copyright">Droits d'auteurs | Copyright &copy; 2021, Guillaume Corniglion, Tichique Luis, Sacha Mokotowitch </p>
            <p class="link">
                <a href="accueil_admin.php">Administrateur</a>
            </p>
        </div>
    </footer>

</body>

</html>