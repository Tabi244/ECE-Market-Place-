<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="icon" href="../images/eceMarketPlaceLogo.png" />
    <link rel="stylesheet" type="text/css" href="style/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">


    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
        crossorigin="anonymous"></script>

    <link rel="stylesheet" href="style.css">
	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}
		
		body {
			margin: 0;
			padding: 0;
			height: 100vh;
		}

		#carouselExemple {
			width: 40%;
			margin: 0 auto;
			margin-top: 100px;
			background-color: #6699ff;
		}

		.carousel-item img {
			width: 60%;
			height: 450px;
			text-align: center;
		}

</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1></br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>     
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
</br>

</header>
<h2 class="ti">Nos best-sellers</h2>
    <div id="carouselExemple" class="carousel slide" data-ride="carousel" data-interval="3000">

        <ol class="carousel-indicators">
            <li data-target="#carouselExemple" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExemple" data-slide-to="1"></li>
            <li data-target="#carouselExemple" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">

            <div class="carousel-item active">
                <img src="images/Items/25.jpg" class="d-block">
            </div>

            <div class="carousel-item">
                <img src="images/Items/12.jpg" class="d-block">
            </div>

            <div class="carousel-item">
                <img src="images/Items/6.jpg" class="d-block">
            </div>
			
            <div class="carousel-item">
                <img src="images/Items/23.jpg" class="d-block">
            </div>

        </div>

        <a href="#carouselExemple" class="carousel-control-prev" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="ture"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a href="#carouselExemple" class="carousel-control-next" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>


    <script>
        $('.carousel').carousel({

            pause: "null"

        })
    </script>
<br><br>
<h2 class="ti">Notre séléction du jour...</h2>



<body>



    <div id="carouselExemple" class="carousel slide" data-ride="carousel" data-interval="3000">

        <ol class="carousel-indicators">
            <li data-target="#carouselExemple" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExemple" data-slide-to="1"></li>
            <li data-target="#carouselExemple" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">

            <div class="carousel-item active">
                <img src="images/Items/4.jpg" class="d-block">
            </div>

            <div class="carousel-item">
                <img src="images/Items/8.jpg" class="d-block">
            </div>

            <div class="carousel-item">
                <img src="images/Items/17.jpg" class="d-block">
            </div>
			
            <div class="carousel-item">
                <img src="images/Items/16.jpg" class="d-block">
            </div>

        </div>

        <a href="#carouselExemple" class="carousel-control-prev" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="ture"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a href="#carouselExemple" class="carousel-control-next" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>


    <script>
        $('.carousel').carousel({

            pause: "null"

        })
    </script>
</body>

</html>


</body>


<br><br><br><br><br>

<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur   </a> <a href="deconnexion.php">     Déconnexion</a> </h6>

</div>