<?php
    session_start();
    
    header( 'content-type: text/html; charset=utf-8' );
    
    //Récupération des données venant de la page des Items
    $ID_Articles = isset($_POST["ID_Articles"])? $_POST["ID_Articles"] : "";
    $Catégorie = isset($_POST["Catégorie"])? $_POST["Catégorie"] : "";
    $Nom_article = isset($_POST["Nom_article"])? $_POST["Nom_article"] : "";
    $Qualite = isset($_POST["Qualite"])? $_POST["Qualite"] : "";
    $Defaut = isset($_POST["Defaut"])? $_POST["Defaut"] : "";
    $TypeAchat = isset($_POST["TypeAchat"])? $_POST["TypeAchat"] : "";
    $Prix = isset($_POST["Prix"])? $_POST["Prix"] : "";
    $Photo_article = isset($_POST["Photo_article"])? $_POST["Photo_article"] : "";
	$Video = isset($_POST["Video"])? $_POST["Video"] : "";

    $erreur = "";
    $extensionsValides = array('jpg', 'jpeg', 'png');
    $datetime = date("Y-m-d", strtotime('+7 day', mktime(0, 0, 0, date('m'), date('d'), date('Y')))) . " " . date("H:i:s", strtotime('+2 hour'));

    //Identification de notre BDD
    $database = "ece_marketplace" ;

    //Connexion dans notre BDD
    //Rappel : Votre serveur = localhost | votre login = root | votre MDP = '' (rien)
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    //Si le bouton "Ajouter un Item" est cliqué
    if (isset($_POST["btn_item"])) {
        //Si la BDD existe
        if ($db_found) {
            $sql = "INSERT INTO articles(ID_Articles, Catégorie, Nom_article, Qualite, Defaut, TypeAchat, Prix, Photo_article, Video) VALUES('$ID_Articles', '$Catégorie', '$Nom_article', '$Qualite', '$Defaut', '$TypeAchat','$Prix', '$Photo_article', '$Video')";
            $result = mysqli_query($db_handle, $sql);
            /*  
            $sql = "SELECT * FROM articles WHERE Nom_article = '$Nom_article' AND Catégorie = '$Catégorie' AND TypeAchat = '$TypeAchat'";
            $result = mysqli_query($db_handle, $sql);
            $data = mysqli_fetch_assoc($result);
            $ID = $data['ID_Articles'];
            
            $sql = "UPDATE items SET Qualite = '$Qualite' WHERE ID = '$ID'";
            $result = mysqli_query($db_handle, $sql);
            $sql = "UPDATE items SET Defaut = '$Defaut' WHERE ID = '$ID'";
            $result = mysqli_query($db_handle, $sql);
            $sql = "UPDATE items SET Prix = '$Prix' WHERE ID = '$ID'";
            $result = mysqli_query($db_handle, $sql);
            $sql = "UPDATE items SET Video = '$Video' WHERE ID = '$ID'";
            $result = mysqli_query($db_handle, $sql);

            }
			*/
            if ($erreur != "") {
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}
		
		#titre{
			text-align: center;
		}

</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1></br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages_vendeur.php">Notifications</a></li>   
		<li><a href="panier_vendeur.php">Panier</a></li>     
		<li><a href="moncompte_vendeur.php">Votre compte</a></li>     
	</ul>
</br>

</header>

<header class="container-fluid">
    <div id="titre">
        <h2>Ajout d'un objet - vendeur</h2>
    </div>
</header>
<br>

	<div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-offset-4 col-md-offset-4 "></div>
            <div class="col-lg-4 col-md-4">
                <form class="form-signin" action="formajout_objet_vendeur.php" method="post" enctype="multipart/form-data">
                    <label for="ID_Articles" class="sr-only">ID</label>
                    <input type="number" id="ID_Articles" name="ID_Articles" class="form-control" placeholder="ID" required>
					
                    <label for="Catégorie">Catégorie</label>
                    <select id="Catégorie" name="Catégorie" size="1" class="form-control" required>
                        <option selected></option>
                        <option>Meubles et objets d'art</option>
                        <option>Accessoires VIP</option>
                        <option>Matériels scolaires</option>
                    </select>
					
                    <label for="Nom-article" class="sr-only">Nom de l'article</label>
                    <input type="text" id="Nom-article" name="Nom-article" class="form-control" placeholder="Nom">
					
                    <label for="Qualite" class="sr-only">Qualité</label>
                    <input type="text" id="Qualite" name="Qualite" class="form-control" placeholder="Qualité">
					
                    <label for="Defaut" class="sr-only">Défauts</label>
                    <input type="text" id="Defaut" name="Defaut" class="form-control" placeholder="Défauts">
					
                    <label for="TypeAchat">Type D'achat</label>
                    <select id="TypeAchat" name="TypeAchat" size="1" class="form-control" required>
                        <option selected></option>
                        <option>Meilleure offre</option>
                        <option>Transaction Vendeur-Client</option>
                        <option>Achetez-le maintenant</option>
                    </select>
					
                    <label for="Prix" class="sr-only">Prix</label>
                    <input type="text" id="Prix" name="Prix" class="form-control" placeholder="Prix" required>
                
                    <label for="Photo_article">Photo de l'objet</label>
                    <input type="file" name="Photo_article" class="form-control">
					
                    <label for="Video">Vidéo</label>
                    <input type="file" name="Video" class="form-control" placeholder="URL de Vidéo">
					
                        <br />
                    <tr colspan="2" align="center">
                        <td>
                            <button class="btn btn-lg btn-primary btn-block" name="btn_item" type="submit">Ajouter l'objet</button>
                        </td>
                    </tr>
                </form>
            </div>
            <div class="col-lg-offset-4 col-md-offset-4"></div>
        </div>
    </div>



<br>

<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur   </a> <a href="deconnexion.php">     Déconnexion</a> </h6>

</div>

</html>

<?php
            }
            else {
				echo'Objet mis en vente';
                header('Location: bienvenue_vendeur.php');
            }
    }
    //Si la BDD n'existe pas
    else {
        echo "<strong>Database not found</strong>";
    }
}

    //Fermer la connexion
    mysqli_close($db_handle);
?>