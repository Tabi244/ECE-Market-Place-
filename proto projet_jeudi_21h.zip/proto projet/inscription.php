<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<style>
	.footer{
		 background-color: #6699ff;
		 text-align: center;
    }
 
    .footer h6{
	     padding: 10px;
    }
	
	.t{
		text-align: center;
	}

	</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1></br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>    
		<li><a href="panier.php">Panier</a></li>             
		<li><a href="login.php">Votre compte</a></li>     
	</ul>
</br></br>
<h1 class="t">Inscription - Acheteur</h1><br>
</header>

<div id="contenu">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-offset-4 col-md-offset-4 "></div>
				<div class="col-lg-4 col-md-4">
                    <form class="form-signin" action="form_inscription.php" method="post">
                        <label for="ID" class="sr-only">ID</label>
                        <input type="number" id="ID_acheteur" name="ID_acheteur" class="form-control" placeholder="ID" required autofocus>
						
                        <label for="Mdp_acheteur" class="sr-only">Mot de Passe</label>
                        <input type="password" id="Mdp_acheteur" name="Mdp_acheteur" class="form-control" placeholder="Mot de Passe" required>
						
                        <label for="Prenom_acheteur" class="sr-only">Prenom</label>
                        <input type="text" id="Prenom_acheteur" name="Prenom_acheteur" class="form-control" placeholder="Prenom" required>
						
                        <label for="Adresse" class="sr-only">Adresse</label>
                        <input type="text" id="Adresse" name="Adresse" class="form-control" placeholder="Adresse" required>
						
                        <label for="CodePostal" class="sr-only">Code Postal</label>
                        <input type="number" id="CodePostal" name="CodePostal" class="form-control" placeholder="CodePostal" required>
						
                        <label for="Ville" class="sr-only">Ville</label>
                        <input type="text" id="Ville" name="Ville" class="form-control" placeholder="Ville" required>
						
                        <label for="Pays" class="sr-only">Pays</label>
                        <input type="text" id="Pays" name="Pays" class="form-control" placeholder="Pays" required>
						
                        <label for="Email_acheteur" class="sr-only">Email</label>
                        <input type="email" id="Email_acheteur" name="Email_acheteur" class="form-control" placeholder="Email" required>
						
                        <label for="Telephone" class="sr-only">Telephone</label>
                        <input type="number" id="Telephone" name="Telephone" class="form-control" placeholder="Telephone" required>
						
                        <label for="NumeroCarte" class="sr-only">Numéro de CB</label>
                        <input type="text" id="NumeroCarte" name="NumeroCarte" class="form-control" placeholder="Numéro de CB" required>
						
                        
                        <label for="Pseudo_acheteur" class="sr-only">Pseudo</label>
                        <input type="text" id="Pseudo_acheteur" name="Pseudo_acheteur" class="form-control" placeholder="Pseudo" required>
                        <br />
                        <tr colspan="2" align="center">
                            <td>
                                <button class="btn btn-lg btn-primary btn-block" name="btn_inscription" type="submit">Envoyer</button>
                            </td>
                        </tr>
                    </form>
            </div>
        <div class="col-lg-offset-4 col-md-offset-4"></div>
    </div>
</div>

<br>
<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur</a></h6>

</div>

</html>