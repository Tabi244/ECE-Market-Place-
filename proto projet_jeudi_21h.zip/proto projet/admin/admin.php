<?php session_start(); ?>

<!DOCTYPE html>
<html>

<head>
    <title>ECE MARKETPLACE - ADMINISTRATEUR</title>
    <meta charset="utf-8">
    <link rel="icon" href="images/eceMarketPlaceLogo.png" />
    <link rel="stylesheet" type="text/css" href="style/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        .bouton {
            height: 150px;
            padding-top: 60px;
            background-color: #6699ff;
            font-size: 1.3em;
        }

        .bouton a {
            color: white;
        }

        .bouton a:hover {
            color: white;
            font-weight: bold;
        }
		
		.link{
			text-align: center;
		}
		
		.copyright{
			text-align: center;
			background-color: #6699ff;
			margin-left: 0px;
		}
		
		#titre{
			text-align: center;
			background-color: #6699ff;
			color: white;
			padding: 10px;
		}


    </style>
</head>

<body>
    <nav class="navbar navbar-expand-md navbar-light">

        <a class="navbar-brand" href="../index.php"><img src="../images/eceMarketPlaceLogo.png" alt="Logo" style="width:70px;"></a>


        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menu">
            <span class="navbar-toggler-icon"></span>
        </button>


        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">Catégories</a>  //a modif
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#.php">Meubles et objets d'art</a> 
                        <a class="dropdown-item" href="#.php">Accessoires VIP</a>  
                        <a class="dropdown-item" href="#.php">Matériels scolaires</a>  
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop_bis" data-toggle="dropdown">Mode d'achat</a>  //a modif
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#.php">Meilleure offre</a>
                        <a class="dropdown-item" href="#.php">Transaction Vendeur-Client</a>
                        <a class="dropdown-item" href="#.php">Achetez-le maintenant</a>
                    </div>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link" href="accueil_vendeur.php">Vendre</a></li> //a modif 
                <li class="nav-item"><a class="nav-link" href="admin.php">Mon compte</a></li>
                <li class="nav-item"><a class="nav-link" href="#.php"><i class="fas fa-shopping-cart" title="Mon Panier"></i></a></li> //a modif
                <li class="nav-item"><a class="nav-link" href="deconnexion.php"><i class="fas fa-power-off" title="Déconnexion"></i></a></li> 
            </ul>
        </div>
    </nav>
    <header class="container-fluid">
        <div id="titre">
            <h1>Bonjour, maître administrateur</h1>
        </div>
		<br><br><br>
    </header>
    <div id="contenu">
        <div class="container">
            <div class="row">
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="liste_items.php">Liste des Items</a></div>
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="liste_vendeurs.php">Liste des Vendeurs</a></div>
            </div>
            <div class="row">
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="ajout_item.php">Ajouter des Items</a></div>
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="ajout_vendeur.php">Ajouter des Vendeurs</a></div>
			</div>
        </div>
        <footer>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <div class="container-fluid">
                <p class="copyright">Droits d'auteurs | Copyright &copy; 2021, Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH <br> 
                <a href="admin/admin.php">Administrateur</a></p>
            </div>
        </footer>
    </div>
</body>

</html>