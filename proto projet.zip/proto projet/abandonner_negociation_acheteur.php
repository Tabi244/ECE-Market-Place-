<?php
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    
    $id_A = isset($_GET["id_article"])? $_GET["id_article"] : "";

    
    $database = "ece_marketplace" ;
    
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "DELETE FROM meilleureoffre WHERE ID_A = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    header('Location: page_bienvenue.php');
?>