<?php
    session_start() ;
    header( 'content-type: text/html; charset=utf-8' );
    $prix_total = isset($_GET["paiement"])?$_GET["paiement"]:"";
    
    $database = "ece_marketplace" ;
    //bdd = ece_marketplace
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "SELECT * FROM acheteur WHERE ID = '" . $_SESSION['ID'] . "'";
    $result = mysqli_query($db_handle, $sql);
    $data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>

<head>
    <title>ECE MarketPlace</title>
    <meta charset="utf-8">
    //image logo
    <link rel="icon" href="images/ecebay.ico" />
    <link rel="stylesheet" type="text/css" href="accueil.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script>
        function Redirection() {
            document.location.href = "abandon_commande.php";
 </script>
</head>

 <header class="container-fluid">
        <div id="titre">
            <h1>Paiement de <?php echo number_format($prix_total, 2, ',', ' '); ?>€</h1>
        </div>
    </header>
    <div id="contenu">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-offset-4 col-md-offset-4 "></div>
                <div class="col-lg-4 col-md-4">
                    <form class="form-signin" action="validation_commande.php?paiement=<?php echo $prix_total; ?>" method="post"> 
                        <label for="ID_acheteur" class="sr-only">Identifiant</label>
                        <input type="text" id="ID_acheteur" name="ID_acheteur" class="form-control" placeholder="ID_acheteur" value="<?php echo $data['ID_acheteur']; ?>" required autofocus>
                        <label for="Mdp_acheteur" class="sr-only">Mot de passe</label>
                        <input type="text" id="Mdp_acheteur" name="Mdp_acheteur" class="form-control" placeholder="Mdp_acheteur" value="<?php echo $data['Mdp_acheteur']; ?>" required autofocus>
                        <label for="Prenom_acheteur" class="sr-only">Prénom de l'acheteur</label>
                        <input type="text" id="Prenom_acheteur" name="Prenom_acheteur" class="form-control" placeholder="Prenom_acheteur" value="<?php echo $data['Prenom_acheteur']; ?>" required>
                        <label for="Adresse" class="sr-only">Adresse
                        </label>
                        <input type="text" id="Adresse" name="Adresse" class="form-control" placeholder="Adresse" value="<?php echo $data['Adresse']; ?>" required>
                        <label for="CodePostal" class="sr-only">Code Postal
                        </label>
                        <input type="text" id="CodePostal" name="CodePostal" class="form-control" placeholder="Code Postal" value="<?php echo $data['CodePostal']; ?>" maxlength="5" minlength="5" required>
                        <label for="Ville" class="sr-only">Ville
                        </label>
                        <input type="text" id="Ville" name="Ville" class="form-control" placeholder="Ville" value="<?php echo $data['Ville']; ?>" required>
                        <label for="Pays" class="sr-only">Pays
                        </label>
                        <input type="text" id="Pays" name="Pays" class="form-control" placeholder="Pays" value="<?php echo $data['Pays']; ?>" required>
                         <label for="Email_acheteur" class="sr-only">E-mail
                        </label>
                        <input type="email" id="Email_acheteur" name="Email_acheteur" class="form-control" placeholder="Email_acheteur" value="<?php echo $data['Email_acheteur']; ?>" required>
                        <label for="Telephone" class="sr-only">Numéro de Téléphone
                        </label>
                        <input type="Telephone" id="Telephone" name="Telephone" class="form-control" placeholder="Numéro de Téléphone" value="<?php echo $data['Telephone']; ?>" required>
                        <br />
                        <br />
                        <label for="TypeCarte">Type de Carte
                        </label>
                        <select id="TypeCarte" name="TypeCarte" size="1" class="form-control" placeholder="Type de Compte" required>
                            <option selected></option>
                            <option>Visa</option>
                            <option>MasterCard</option>
                            <option>American Express</option>
                            <option>Paypal</option>
                        </select>
                        <label for="Num_CB" class="sr-only">Numéro de Carte
                        </label>
                        <input type="text" id="Num_CB" name="Num_CB" class="form-control" placeholder="Numéro de carte bancaire" value="<?php echo $data['Num_CB']; ?>" maxlength="16" minlength="16" required>
                        <label for="Nom_CB" class="sr-only">Nom du propirétaire de la carte
                        </label>
                        <input type="text" id="Nom_CB" name="Nom_CB" class="form-control" placeholder="Nom du propiétaire de la carte" value="<?php echo $data['Nom_CB']; ?>" maxlength="16" minlength="2" required>
                        <label for="DateExpiration" class="sr-only">Date d'Expiration
                        </label>
                        <input type="text" id="DateExpiration" name="DateExpiration" class="form-control" placeholder="Date d'expiration (MM/AAAA)" required>
                        <label for="CodeSecret" class="sr-only">CVV
                        </label>
                        <input type="password" id="CodeSecret" name="CodeSecret" class="form-control" maxlength="3" minlength="3" placeholder="CVV" required>

                        <br /><br />
                        <tr colspan="2" align="center">
                            <td>
                                <button class="btn btn-lg btn-primary btn-block" name="btn_paiement" type="submit">Envoyer
                                </button>
                            </td>
                        </tr>
                    </form>
                    <br />
                    <button class="btn btn-lg btn-danger btn-block" name="btn_abandonner" type="button" onclick="Redirection()">Abandonner la commande
                    </button>
                </div>
                <div class="col-lg-offset-4 col-md-offset-4"></div>
            </div>
        </div>

        
        <footer>
            <div class="container-fluid">
                <p class="copyright">Droit d'auteur | Copyright &copy; 2021, Guillaume Corniglion, Tichique Luis, Sacha Mokotowitch  </p>
                <p class="link">
                    <a href="accueil_admin.php">Administrateur</a>
                </p>
            </div>
        </footer>
    </div>
</body>

</html>
