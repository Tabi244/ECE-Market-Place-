<?php

	session_start();

	$Email='azerty@gmail.com';
	$Motdepasse='guillaumemdp';

	if(isset($_POST['btn_connexion'])){
		$inputEmail=$_POST['inputEmail'];
		$inputPassword=$_POST['inputPassword'];
		
		if($inputEmail&&$inputPassword){
			echo'Connexion en cours... ';
			
			if($inputEmail==$Email&&$inputPassword==$Motdepasse){
				echo'Access granted';
				$SESSION['inputEmail']=$inputEmail;
				header('Location: bienvenue.php');
				
			}else echo'Echec. Pseudo et/ou mot de passe invalides';
		}else echo'Veuillez remplir tout les champs';
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<script>
        function Redirection() {
            document.location.href = "inscription.php";   //fichier qui amène au formulaire inscription
        }
	</script>
</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1><br/></br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li>
		<li><a href="messages.php">Notifications</a></li>    
		<li><a href="panier.php">Panier</a></li>             
		<li><a href="login.php">Votre compte</a></li>       
	</ul>
</br></br>
</header>


        <div class="container">
            <div class="row d-flex justify-content-center mt-5 mb-5">
                <div class="col-lg-offset-4 col-md-offset-4 "></div>
                <div class="col-lg-4 col-md-4">
                    <form class="form-signin" action="index.php" method="post">
                        <label for="inputEmail" class="sr-only">E-mail</label>
                        <input type="email" id="inputEmail" name="inputEmail" class="form-control" placeholder="Email address" required autofocus>
                        <label for="inputPassword" class="sr-only">Mot de passe</label>
                        <input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required>
                        <div class="checkbox mb-3">
                            <label>
                                <input type="checkbox" value="remember-me"> Se souvenir de moi
                            </label>
                        </div>
                        <tr colspan="2" align="center">
                            <td>
                                <button class="btn btn-lg btn-primary btn-block" name="btn_connexion" type="submit">Connexion</button>
                            </td>
                        </tr>
                    </form>
                    <br />
                    <button class="btn btn-lg btn-primary btn-block" name="btn_inscription" type="button" onclick="Redirection()">S'inscrire</button>
                </div>
                <div class="col-lg-offset-4 col-md-offset-4"></div>
            </div>
        </div>
		</br></br></br></br></br></br></br></br></br>


</html>

