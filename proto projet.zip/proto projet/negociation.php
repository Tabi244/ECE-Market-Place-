<?php
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    $id_article = isset($_GET["ID_article"])? $_GET["ID_article"] : "";

    
    $database = "ece_marketplace" ;

    //BDD= ece_marketplace
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "SELECT * FROM article WHERE ID_article = '$id_article'";
    $result = mysqli_query($db_handle, $sql);
    $data_article = mysqli_fetch_assoc($result);
    $prix_article = $data_article['Prix'];
    
    $sql = "SELECT * FROM vendeur WHERE Email = '" . $data_article['Email'] . "'";
    $result = mysqli_query($db_handle, $sql);
    $data_vendeur = mysqli_fetch_assoc($result);
    $Email_Vendeur = $data_vendeur['Email'];

    $Email_Acheteur = $_SESSION['Email'];

    $sql = "SELECT * FROM meilleureoffre WHERE ID_article = '$id_article'";
    $result = mysqli_query($db_handle, $sql);
    if(mysqli_num_rows($result) === 0) {
        $sql = "INSERT INTO meilleureoffre(ID_article, EmailVendeur, EmailAcheteur, PrixInitial, PrixNegocie, Tour) VALUES('$id_article', '$Email_Vendeur', '$Email_Acheteur', '$prix_article', '$prix_article', '1')";
        $result = mysqli_query($db_handle, $sql);
    }

    $sql = "SELECT * FROM meilleureoffre WHERE ID_article = '$id_article'";
    $result = mysqli_query($db_handle, $sql);
    $data_offre = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>

<head>
    <title>ECE MarketPlace</title>
    <meta charset="utf-8">

    <style>
        .photo_item {
            height: 220px;
        }

        .style {
            text-decoration: underline;
            font-style: italic;
            font-size: 0.9rem;
        }
        table tr td {
            text-align: center;
        }

    </style>
</head>

<body>
     <header class="container-fluid">
        <div id="titre">
            <h1>Négociation<br />Tour n°<?php echo $data_offre['Tour']; ?></h1>
        </div>
    </header>
    <div id="contenu">
        <div class="container">
            <?php
            if ($data_offre['PrixInitial'] !== $data_offre['PrixNegocie']) {
            ?>
            <div class="col-lg-12 col-md-12 display-4" align="center">
                Prix Proposé : <span style="color: #003d66; font-weight: bold;"><?php echo number_format($data_offre['PrixNegocie'], 2, ',', ' '); ?>€</span>
                <br />
                <?php
                if($data_offre['Negociation'] == 'O') {
                    echo "Le vendeur a accepté la proposition.";
                }
                ?>
            </div>
<?php
            }
            ?>
            <br /><br />
            <div class="row border d-flex align-items-center">
                <div class="col-lg-4 col-md-4" align="center"><a href="images/Items/<?php echo $data_article['Photo']; ?>" target="_blank">
                    <img class="photo_article" alt="photo de l'article" src="images/Items/<?php echo $data_article['Photo']; ?>" /></a></div>
                <div class="col-lg-6 col-md-6">
                    <table align="center">
                        <tr>
                            <td class="style">ID article</td>
                            <td><?php echo $data_article['ID_article']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Catégorie</td>
                            <td><?php echo $data_article['Catégorie']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Nom de l'article</td>
                            <td><?php echo $data_article['Nom_article']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Qualité</td>
                            <td><?php echo $data_article['Qualite']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Type d'Achat</td>
                            <td><?php echo $data_article['TypeAchat']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Défaut</td>
                            <td><?php echo $data_article['Defaut']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Prix</td>
                            <td><?php echo number_format($data_article['Prix'], 2, ',', ' '); ?>€</td>
                        </tr>

                        <tr>
                            <td class="style">Nom du vendeur</td>
                            <td>
                                <?php
                                    if ($Email_Vendeur != "") {
                                        echo $data_vendeur['Nom'] . " " . $data_vendeur['Prenom'];
                                    }
                                    else {
                                        echo "Inconnu...";
                                    }
                                ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-lg-2 col-md-2">
                    <?php
                    if($data_offre['Negociation'] != 'O') {
                        if($data_offre['Tour'] == 5) {
?>
                    
                    <form method="post" action="panier.php?id_article=<?php echo $data_article['ID_article']; ?>">
                        <button type="submit" class="btn btn-success" name="negociation_reussie">Accepter l'offre</button>
                    </form>
                    <br />
                    <form method="post" action="abandon_nego_acheteur.php?id_article=<?php echo $id_article; ?>">
                        <button type="submit" class="btn btn-danger" name="negociation_echouee">Refuser l'offre</button>
                    </form>
                    

<?php
                        }
                        else {
?>
                    <form method="post" action="formNegocier.php?ID=<?php echo $data_article['ID_article']; ?>">
                        <label for="PrixNegocie" class="sr-only">Proposer un Prix</label>
                        <input class="form-control" type="number" min="0" max="<?php echo $data_offre['PrixInitial']; ?>" name="PrixNegocie" id="PrixNegocie" required autofocus />
                        <button type="submit" class="btn btn-success" name="Negocier">Proposer un prix</button>
                    </form>
<?php
                        }
                    }
                    else {
?>
                    <form method="post" action="panier.php?id_article=<?php echo $data_article['ID_article']; ?>">
                        <button type="submit" class="btn btn-success" name="negociation_reussie">Ajouter au Panier</button>
                    </form>
<?php
                    }
?>
                </div>
            </div>
            <br /><br /><br />
        </div>
        <footer>
            <div class="container-fluid">
                <p class="copyright">Droit d'auteur | Copyright &copy; 2021, Guillaume Corniglion, Tichique Luis, Sacha Mokotowitch
                </p>
                <p class="link">
                    <a href="accueil_admin.php">Administrateur</a>
                </p>
            </div>
        </footer>
    </div>
</body>

</html>
