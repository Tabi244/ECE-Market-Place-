<?php
    session_start() ;
    header( 'content-type: text/html; charset=utf-8' );
    $prix_total = isset($_GET["paiement"])?$_GET["paiement"]:"";
?> 

<!DOCTYPE html>
<html>
<head>
    <title>ECE MarketPlace</title>
 </head>
<header class="container-fluid">
        <div id="titre">
            <h1>Annuler la commande</h1>
        </div>
    </header>
    <div id="contenu">
        <div class="container" align="center" style="font-size: 2.3rem;">
            Votre commande a bien été <span style="color: green; font-weight: bold;">annulée</span>.
            <br />
            Vous pouvez retourner sur la <span style="color: green; font-weight: bold;">page principale</span>...
            <br /><br />
            <a href="page_bienvenue.php" class="btn btn-primary">Revenir à la Page d'accueil</a>
        </div>
        <div style="height: 90px;"></div>
        <footer>
            <div class="container-fluid">
                <p class="copyright">Droit d'auteur | Copyright &copy; 2021, Guillaume Corniglion, Tichique Luis, Sacha Mokotowitch</p>
                <p class="link">
                    <a href="accueil_admin.php">Administrateur</a>
                </p>
            </div>
        </footer>
    </div>


</html>