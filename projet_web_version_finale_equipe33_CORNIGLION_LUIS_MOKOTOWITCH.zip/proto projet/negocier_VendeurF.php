<?php
//negocier_VendeurF
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    $id_A = isset($_GET["ID_Articles"])? $_GET["ID_Articles"] : "";
    
    $PrixNegocie = isset($_POST["PrixNegocie"])? $_POST["PrixNegocie"] : "";

    $database = "ece_marketplace" ;

    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "SELECT * FROM encheres WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data = mysqli_fetch_assoc($result);
    $Tour = $data['Tour'];
    $Tour_Plus_1 = $Tour + 1;
    
    $sql = "UPDATE negociation SET PrixNegocie = '$PrixNegocie' WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $sql = "UPDATE negociation SET Tour = '$Tour_Plus_1' WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);

    header('Location: Negocier_Vendeur.php?ID=' . $id_A);
?>