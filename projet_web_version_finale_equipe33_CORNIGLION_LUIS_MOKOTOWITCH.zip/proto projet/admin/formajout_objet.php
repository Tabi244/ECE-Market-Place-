<?php
    session_start();
    
    header( 'content-type: text/html; charset=utf-8' );
    
    //Récupération des données venant de la page des Items
    $ID_Articles = isset($_POST["ID_Articles"])? $_POST["ID_Articles"] : "";
    $Catégorie = isset($_POST["Catégorie"])? $_POST["Catégorie"] : "";
    $Nom_article = isset($_POST["Nom_article"])? $_POST["Nom_article"] : "";
    $Qualite = isset($_POST["Qualite"])? $_POST["Qualite"] : "";
    $Defaut = isset($_POST["Defaut"])? $_POST["Defaut"] : "";
    $TypeAchat = isset($_POST["TypeAchat"])? $_POST["TypeAchat"] : "";
    $Prix = isset($_POST["Prix"])? $_POST["Prix"] : "";
    $Photo_article = isset($_POST["Photo_article"])? $_POST["Photo_article"] : "";
	$Video = isset($_POST["Video"])? $_POST["Video"] : "";

    $erreur = "";
    $extensionsValides = array('jpg', 'jpeg', 'png');
    $datetime = date("Y-m-d", strtotime('+7 day', mktime(0, 0, 0, date('m'), date('d'), date('Y')))) . " " . date("H:i:s", strtotime('+2 hour'));

    //Identification de notre BDD
    $database = "ece_marketplace" ;

    //Connexion dans notre BDD
    //Rappel : Votre serveur = localhost | votre login = root | votre MDP = '' (rien)
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
// si on clique sur ajouter un item:
    if (isset($_POST["btn_item"])) {
        //Si la BDD existe
        if ($db_found) {
            $sql = "INSERT INTO articles(ID_Articles, Catégorie, Nom_article, Qualite, Defaut, TypeAchat, Prix, Photo_article, Video) VALUES('$ID_Articles', '$Catégorie', '$Nom_article', '$Qualite', '$Defaut', '$TypeAchat','$Prix', '$Photo_article', '$Video')";
            $result = mysqli_query($db_handle, $sql);

            if ($erreur != "") {
?>

<!DOCTYPE html>
<html>

<head>
    <title>ECE MARKETPLACE - ADMINISTRATEUR</title>
    <meta charset="utf-8">
    <link rel="icon" href="../images/Logo.png" />
    <link rel="stylesheet" type="text/css" href="style/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        .bouton {
            height: 150px;
            padding-top: 60px;
            background-color: #6699ff;
            font-size: 1.3em;
        }

        .bouton a {
            color: white;
        }

        .bouton a:hover {
            color: white;
            font-weight: bold;
        }
		
		.link{
			text-align: center;
		}
		
		.copyright{
			text-align: center;
			background-color: #6699ff;
			margin-left: 0px;
		}
		
		#titre{
			text-align: center;
			background-color: #6699ff;
			color: white;
			padding: 10px;
		}
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.formObj{
			text-align: center;
		}


    </style>
</head>

<body>

<header class="container-fluid">
    <div id="titre">
        <h1>Ajout d'un objet</h1>
    </div>
</header>
<br><br>
<h2 class="formObj">Veuillez remplir tous les champs</h2>
<br><br>

	<div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-offset-4 col-md-offset-4 "></div>
            <div class="col-lg-4 col-md-4">
                <form class="form-signin" action="formajout_objet.php" method="post" enctype="multipart/form-data">
                    <label for="ID_Articles" class="sr-only">ID</label>
                    <input type="number" id="ID_Articles" name="ID_Articles" class="form-control" placeholder="ID" required>
					
                    <label for="Catégorie">Catégorie</label>
                    <select id="Catégorie" name="Catégorie" size="1" class="form-control" required>
                        <option selected></option>
                        <option>Meubles et objets d'art</option>
                        <option>Accessoires VIP</option>
                        <option>Matériels scolaires</option>
                    </select>
					
                    <label for="Nom_article" class="sr-only">Nom de l'article</label>
                    <input type="text" id="Nom_article" name="Nom_article" class="form-control" placeholder="Nom">
					
                    <label for="Qualite" class="sr-only">Qualité</label>
                    <input type="text" id="Qualite" name="Qualite" class="form-control" placeholder="Qualité">
					
                    <label for="Defaut" class="sr-only">Défauts</label>
                    <input type="text" id="Defaut" name="Defaut" class="form-control" placeholder="Défauts">
					
                    <label for="TypeAchat">Type D'achat</label>
                    <select id="TypeAchat" name="TypeAchat" size="1" class="form-control" required>
                        <option selected></option>
                        <option>Meilleure offre</option>
                        <option>Transaction Vendeur-Client</option>
                        <option>Achetez-le maintenant</option>
                    </select>
					
                    <label for="Prix" class="sr-only">Prix</label>
                    <input type="text" id="Prix" name="Prix" class="form-control" placeholder="Prix" required>
                
                    <label for="Photo_article">Photo de l'objet</label>
                    <input type="file" name="Photo_article" class="form-control">
					
                    <label for="Video">Vidéo</label>
                    <input type="file" name="Video" class="form-control" placeholder="URL de Vidéo">
					
                        <br />
                    <tr colspan="2" align="center">
                        <td>
                            <button class="btn btn-lg btn-primary btn-block" name="btn_item" type="submit">Ajouter l'objet</button>
                        </td>
                    </tr>
                </form>
            </div>
            <div class="col-lg-offset-4 col-md-offset-4"></div>
        </div>
    </div>




</body>

<br><br><br>
<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin.php">Administrateur    </a> <a href="../deconnexion.php">     Déconnexion</a></h6>

</div>

</html>

<?php
            }
            else {
                header('Location: liste_objets.php');
            }
    }
    //Si la BDD n'existe pas
    else {
        echo "<strong>Database not found</strong>";
    }
}

    //Fermer la connexion
    mysqli_close($db_handle);
?>
