<?php session_start(); ?>

<!DOCTYPE html>
<html>

<head>
    <title>ECE MARKETPLACE - ADMINISTRATEUR</title>
    <meta charset="utf-8">
    <link rel="icon" href="../images/Logo.png"/>
    <link rel="stylesheet" type="text/css" href="style/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        .bouton {
            height: 150px;
            padding-top: 60px;
            background-color: #6699ff;
            font-size: 1.3em;
        }

        .bouton a {
            color: white;
        }

        .bouton a:hover {
            color: white;
            font-weight: bold;
        }
		
		.link{
			text-align: center;
		}
		
		.copyright{
			text-align: center;
			background-color: #6699ff;
			margin-left: 0px;
		}
		
		#titre{
			text-align: center;
			background-color: #6699ff;
			color: white;
			padding: 10px;
		}


    </style>
</head>

<body>

    <header class="container-fluid">
        <div id="titre">
            <h1>Bonjour, maître administrateur</h1>
        </div>
		<br><br><br><br><br><br>
    </header>
    <div id="contenu">
        <div class="container">
            <div class="row">
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="liste_objets.php">Liste des Objets</a></div>
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="liste_vendeurs.php">Liste des Vendeurs</a></div>
            </div>
            <div class="row">
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="ajout_objet.php">Ajouter un objet</a></div>
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="ajout_vendeur.php">Ajouter un vendeur</a></div>
			</div>
        </div>
        <footer>
			<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            <div class="container-fluid">
                <p class="copyright">Droits d'auteurs | Copyright &copy; 2021, Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH <br> 
                <a href="admin.php">Administrateur    </a> <a href="../deconnexion.php">     Déconnexion</a></p>
            </div>
        </footer>
    </div>
</body>

</html>