<?php
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    
    $id_A = isset($_GET["ID_Articles"])? $_GET["ID_Articles"] : "";
    $a = isset($_GET["a"])? $_GET["a"] : "";
    $prix_total = 0;
//Permet de récupération les données
    $database = "ece_marketplace" ;
    //bdd = ece_marketplace
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "SELECT * FROM articles WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data_article = mysqli_fetch_assoc($result);
    
    $Email_Vendeur = $data_article['Email_vendeur'];
    $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
    $result = mysqli_query($db_handle, $sql);
    $data_vendeur = mysqli_fetch_assoc($result);


    //Panier Achats Immédiat
    if(!isset($_SESSION['enchere'])) {
		$_SESSION['enchere'] = array();
    }
    //Panier Négo
    if(!isset($_SESSION['Panier_NE'])) {
		$_SESSION['Panier_NE'] = array();
    }
    //Panier Enchères
    if(!isset($_SESSION['Panier_E'])) {
		$_SESSION['Panier_E'] = array();
    }
	array_push($_SESSION['enchere'], $id_A);

	 if(isset($_POST['negociation_validé'])) {
        array_push($_SESSION['Panier_NE'], $id_A);
    }
    //Le bouton negotion validé enclenché 
    if(isset($_POST['enchere'])) {
        array_push($_SESSION['Panier_E'], $id_A);
    }
    //bouton enchere enclenché


    //Supprimer AI

    if($a == 1) {
        unset($_SESSION['Panier_AI'][array_search($data_article['ID_Articles'], $_SESSION['Panier_AI'])]);
    }
    //Supprimer NE 
    if($a == 2) {
        unset($_SESSION['Panier_NE'][array_search($data_article['ID_Articles'], $_SESSION['Panier_NE'])]);
    }
    //Supprimer E
    if($a == 3) {
        unset($_SESSION['Panier_E'][array_search($data_article['ID_Articles'], $_SESSION['Panier_E'])]);
    }
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>

	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}

</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  
		<a href="index.php">
			<img src="images/Logo.png" style="width:70px"/>
		</a>
	</h1>
	</br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages_acheteur.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>         
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
</br></br>

</header>
<body>



</br>


<div id="contenu">
        <div class="container">
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-12 text-center"></div>
                <div class="col-lg-10 col-md-10 col-sm-12 text-center">
<?php
            if(count($_SESSION['enchere']) === 0 && count($_SESSION['Panier_NE']) === 0 && count($_SESSION['Panier_E']) === 0) {
                echo "<h1 class='text-center'>Votre Panier ne comporte aucun article!</h1>";
            }
            else {
?>
                    <table class='table table-hover table-responsive-sm'>
                        <thead>
                            <tr>
                                <th align='center'>Libellé</th>
                                <th align='center'>Vendeur</th>
                                <th align='center'>Prix</th>
                                <th align='center>'>Offre(€)</th>
                                <th align="center">Tour</th>
                                <th style='text-align: center'>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                if(!empty($_SESSION['enchere'])) {
                    foreach($_SESSION['enchere'] as $offre) {
                        $sql = "SELECT * FROM articles WHERE ID_Articles = '$offre'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_article = mysqli_fetch_assoc($result);
    
                        $Email_Vendeur = $data_article['Email_vendeur'];
                        $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_vendeur = mysqli_fetch_assoc($result);
                    
                        $prix_total += $data_article['Prix'];
?>
                            <tr>
                                <td>Vase art moderne ours polaire</td>
                                <td>sacha.mokotowitch@edu.ece.fr</td>
                                <td>45.000€</td>
                                <td><input type="number" name="offre"></td>
                                <td>1</td>
                                <td><input type="button" name="confirmer" value ="Confirmer offre"></td>
                                <td align='center'>
                                    <div class='btn-group btn-group-sm'>
                                        <a class="btn btn-danger" href="TypeAchatNegociation.php?id_article=<?php echo $data_article['ID_Articles']; ?>&amp;a=1">Supprimer</a>
                                        

                                    </div>
                                </td>
                            </tr>
<?php
                    }
                    session_destroy();
                }
                
                if(!empty($_SESSION['Panier_NE'])) {
                    foreach($_SESSION['Panier_NE'] as $element_NE) {
                        $sql = "SELECT * FROM articles WHERE ID_Articles = '$element_NE'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_article = mysqli_fetch_assoc($result);
    
                        $Email_Vendeur = $data_article['Email_vendeur'];
                        $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_vendeur = mysqli_fetch_assoc($result); //Nom du Vendeur
                    
                        $sql = "SELECT * FROM negociation WHERE ID_MeilleurOffre= '$id_A'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_ne = mysqli_fetch_assoc($result);
                    
                        $prix_total += $data_ne['PrixNegocie'];
?>
                            <tr>
                                <td><?php echo $data_article['Nom_article']; ?></td>
                                <td><?php echo $data_vendeur['Email_vendeur']; ?></td>
                                <td>1</td>
                                <td><?php echo number_format($data_ne['PrixNegocie'], 2, ',', ' '); ?>€</td>
                                <td align='center'>
                                    <div class='btn-group btn-group-sm'>
                                        
                                        <a class="btn btn-danger" href="panier_acheteur.php?id_article=<?php echo $data_article['ID_Articles']; ?>&amp;a=2">Supprimer</a>
                                        

                                    </div>
                                </td>
                            </tr>
<?php
                    }
                    unset($element_NE);
                }
                
                if(!empty($_SESSION['Panier_E'])) {
                    foreach($_SESSION['Panier_E'] as $element_E) {
                        $sql = "SELECT * FROM articles WHERE ID_Articles = '$element_E'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_article = mysqli_fetch_assoc($result);
    
                        $Email_Vendeur = $data_article['Email_vendeur'];
                        $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_vendeur = mysqli_fetch_assoc($result); 
                    
                        $sql = "SELECT * FROM encheres WHERE ID_Articles = '$id_A'";
                        $result = mysqli_query($db_handle, $sql);
                        $data_Encheres = mysqli_fetch_assoc($result);
                    
                        $prix_total += ($data_E['PrixFin'] + 1);
?>
                            <tr>
                                <td><?php echo $data_article['Nom_article']; ?></td>
                                <td><?php echo $data_vendeur['Email_vendeur']; ?></td>
                                <td>1</td>
                                <td><?php echo number_format($data_E['PrixFin'] + 1, 2, ',', ' '); ?>€</td>
                                <td align='center'>
                                    <div class='btn-group btn-group-sm'>
                                        <a class="btn btn-danger" href="panier_acheteur.php?id_article=<?php echo $data_article['ID_Articles']; ?>&amp;a=3">Supprimer</a>
                                        

                                    </div>
                                </td>
                            </tr>
<?php
                    }
                    unset($element_E);
                }
?>
                            
                        </tbody>
                    </table>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-12"></div>
            </div>
        </div>
        
    </div>

<?php
            }
?>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>


<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur    </a> <a href="Connexion_vendeur.php">     Vendeur</a></h6>

</div>

</body>

</html>