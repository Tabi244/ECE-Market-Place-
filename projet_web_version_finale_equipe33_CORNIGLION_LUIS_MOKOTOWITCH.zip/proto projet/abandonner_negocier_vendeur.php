<?php
//abandonner_negocier_vendeur
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    $id_A = isset($_GET["ID_Articles"])? $_GET["ID_Articles"] : "";

    $database = "ece_marketplace" ;


    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "DELETE FROM encheres WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    header('Location: negociationencours_Vendeur.php');
?>