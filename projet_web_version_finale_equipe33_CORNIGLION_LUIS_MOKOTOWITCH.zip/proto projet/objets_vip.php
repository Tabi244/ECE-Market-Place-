<?php 
    session_start();

    header( 'content-type: text/html; charset=utf-8' );

    //Identification de notre BDD
    $database = "ece_marketplace" ;
    //Connexion dans notre BDD
    //Rappel : Votre serveur = localhost | votre login = root | votre MDP = '' (rien)
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;

    $sql_article = "SELECT * FROM articles WHERE Categorie LIKE '%Accessoires%'" ;
    $result_article = mysqli_query($db_handle, $sql_article);
?>

<!DOCTYPE html>
<html>

<head>
    <title>ECE MARKETPLACE</title>
    <meta charset="utf-8">
    <link rel="icon" href="images/Logo.png" />
    <link rel="stylesheet" type="text/css" href="style/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
        .photo_item {
            height: 220px;
            width: 300px;
        }

        .puce {
            list-style-type: none;
            text-align: center;
            font-size: 1.3rem;
        }

        .puce strong {
            font-style: italic;
            font-size: 1.7rem;
        }
		
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
	</style>
</head>

<body>
<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1><br><br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>         
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
<br><br>

</header>

        <div class="container">
            <?php
                while ($data_article = mysqli_fetch_assoc($result_article)) {
            ?>
            <div class="row border d-flex align-items-center">
                <div class="col-lg-4 col-md-4" align="center"><a href="images/Items/<?php echo $data_article['lien_photo']; ?>" target="_blank"><img title="Cliquez pour agrandir." class="photo_item" alt="photo de l'Item" src="images/Items/<?php echo $data_article['lien_photo']; ?>" /></a></div>
                <div class="col-lg-6 col-md-6">
                    <ul class="puce">
                        <li><strong><?php echo $data_article['Nom_article']; ?></strong></li>
                        <br />
                        <li>Catégorie : <?php echo $data_article['Categorie']; ?></li>
                        <li>Type d'achat : <?php echo $data_article['TypeAchat']; ?></li>
                        <br />
                        <li><?php echo number_format($data_article['Prix'], 2, ',', ' '); ?>€</li>
                    </ul>
                </div>
				
                <div class="col-lg-2 col-md-2">
                    <form method="post" action="Information_Article.php?ID=<?php echo $data_article['ID_Articles']; ?>">
                        <button type="submit" class="btn btn-info" name="btn_infos">En savoir plus</button>
                    </form>
                </div>
            </div>
            <?php
                echo "<br /><br /><br />";
                }
            ?>

        </div>
		
<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur    </a> <a href="Connexion_vendeur.php">     Vendeur</a></h6>

</div>