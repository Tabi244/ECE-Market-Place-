<?php 
//negociationencours_Vendeur
    session_start();

    header( 'content-type: text/html; charset=utf-8' );

    
    $database = "ece_marketplace" ;
    
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;


    $sql_ne = "SELECT * FROM encheres WHERE Email_Vendeur = '" . $_SESSION['Email_Vendeur'] . "'" ;
    $result_ne = mysqli_query($db_handle, $sql_ne);
?>
<!DOCTYPE html>
<html>

<head>
    <title>ECE MarketPlace</title>
    <meta charset="utf-8">
    <style>
        .photo_item {
            height: 220px;
        }
        .puce {
            list-style-type: none;
            text-align: center;
            font-size: 1.3rem;
        }
        .puce strong {
            font-style: italic;
            font-size: 1.7rem;
        }
    </style>
</head>

<body>

    <header class="container-fluid">
        <div id="titre">
            <h1>Liste Articles en Négociation</h1>
        </div>
    </header>
    <div id="contenu">
        <div class="container">
<?php
            if(mysqli_num_rows($result_ne) == 0) {
?>
            <br /><br /><br /><br />
            <div class="display-4 col-lg-12 col-md-12 col-sm-12" align="center">Il n'existe pas d'article en négociation...</div>
            <br /><br /><br /><br /><br /><br />
<?php               
            }
            else {
                while ($data_ne = mysqli_fetch_assoc($result_ne)) {
                    $sql_item = "SELECT * FROM articles WHERE ID_Articles = '" . $data_ne['ID_Articles'] . "'" ;
                    $result_artcile = mysqli_query($db_handle, $sql_item);
                    $data_article = mysqli_fetch_assoc($result_artcile);
            ?>
            <div class="row border d-flex align-items-center">
                <div class="col-lg-4 col-md-4" align="center"><a href="images/Items/<?php echo $data_article['Photo_article']; ?>" target="_blank"><img title="Cliquez pour agrandir." class="photo_item" alt="photo de l'article" src="images/Items/<?php echo $data_article['Photo_Article']; ?>" /></a></div>
                <div class="col-lg-6 col-md-6">
                    <ul class="puce">
                        <li><strong>
                            <?php echo $data_article['Nom_article']; ?></strong></li>
                        <br />
                        <li>Catégorie : <?php echo $data_article['Categorie']; ?></li>
                        <li>Type d'achat : <?php echo $data_article['TypeAchat']; ?></li>
                        <br />
                        <li><?php echo number_format($data_article['Prix'], 2, ',', ' '); ?>€</li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-2">
                    <form method="post" action="Information_Article.php?ID=<?php echo $data_article['ID_Articles']; ?>">
                        <button type="submit" class="btn btn-info" name="btn_infos">En savoir plus</button>
                    </form>
                </div>
            </div>
            <br /><br /><br />
            <?php
                }
            }
            ?>

        </div>
        <footer>
            <div class="container-fluid">
                <p class="copyright">Droits d'auteurs | Copyright &copy; 2021, Guillaume Corniglion, Tichique Luis, Sacha Mokotowitch</p>
                <p class="link">
                    <a href="index.php">Administrateur</a>
                </p>
            </div>
        </footer>
    </div>
</body>

</html>