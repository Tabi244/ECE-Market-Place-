<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="page_bienvenue.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}
		
        .card-img-top {
            width: 350px;
            height: 200px;
            background-position: center center;
        }
		
		#photo{
			text-align: center; 
		}
		

</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/Logo.png" style="width:70px"/></a></h1><br><br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>         
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
<br><br>

</header>

<body>
   <div class="container">
            <div class="row">
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="parcourir_Categorie.php">Catégories</a></div>
                <div class="col-lg-offset-2 col-md-2 d-flex justify-content-around"></div>
                <div class="bouton col-lg-3 col-md-3 border d-flex justify-content-around"><a href="parcourir_TypeAchat.php">Type d'achat</a></div>
			</div>
	</div>

</body>

<div id="photo">
	<img src="images/Logo.png"/>
</div>



<br><br><br><br><br>

<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur    </a> <a href="deconnexion.php">     Déconnexion</a></h6>

</div>