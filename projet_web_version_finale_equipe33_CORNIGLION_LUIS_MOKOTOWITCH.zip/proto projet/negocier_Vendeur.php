<?php
//negocier_Vendeur
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    $id_A = isset($_GET["ID_Articles"])? $_GET["ID_Articles"] : "";

    
    $database = "ece_marketplace" ;

    
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "SELECT * FROM articles WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data_article = mysqli_fetch_assoc($result); 
    
    $sql = "SELECT * FROM acheteur WHERE Email_acheteur = '" . $data_article['Email_acheteur'] . "'";
    $result = mysqli_query($db_handle, $sql);
    $data_acheteur = mysqli_fetch_assoc($result);
    $Email_Acheteur = $data_acheteur['Email_acheteur'];

    $Email_Vendeur = $_SESSION['Email_Vendeur'];

    $sql = "SELECT * FROM encheres WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data_offre = mysqli_fetch_assoc($result); 
?>
<header class="container-fluid">
        <div id="titre">
            <h1>Négociation<br />Tour n°<?php echo $data_offre['Tour']; ?></h1>
        </div>
    </header>

    <div id="contenu">
        <div class="container">
            <div class="col-lg-12 col-md-12 display-4" align="center">Prix Proposé : <span style="color: #003d66; font-weight: bold;"><?php echo number_format($data_offre['PrixNegocie'], 2, ',', ' '); ?>€</span></div>
            <br /><br />
            <div class="row border d-flex align-items-center">
                <div class="col-lg-4 col-md-4" align="center"><a href="images/Items/<?php echo $data_artcile['Photo_article']; ?>" target="_blank"><img class="photo_item" alt="photo de l'article" src="images/Items/<?php echo $data_article['Photo_article']; ?>" /></a></div>
                <div class="col-lg-6 col-md-6">
                    <table align="center">
                        <tr>
                            <td class="style">Numéro d'Identification</td>
                            <td><?php echo $data_article['ID_Articles']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Nom de l'article</td>
                            <td><?php echo $data_article['Nom_article']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Nom du vendeur</td>
                            <td>
<?php
                                    if ($Email_Vendeur != "") {
                                        echo $_SESSION['Nom_vendeur'] . " " . $_SESSION['Prenom_vendeur'];
                                    }
                                    else {
                                        echo "Inconnu...";
                                    }
?>
                                    
                                </td>
                        </tr>
                        <tr>
                            <td class="style">Catégorie</td>
                            <td><?php echo $data_article['Categorie']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Type d'Achat</td>
                            <td><?php echo $data_article['TypeAchat']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Qualité</td>
                            <td><?php echo $data_article['Qualite']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Défaut</td>
                            <td><?php echo $data_artcile['Defaut']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Prix</td>
                            <td><?php echo number_format($data_article['Prix'], 2, ',', ' '); ?>€</td>
                        </tr>
                    </table>
                </div>
                <div class="col-lg-2 col-md-2">
                    <br />
                    <?php
                    if($data_offre['Negociation'] != 'O') {
                    ?>
                    <a class="btn btn-success" href="NegociationA_Vendeur.php?ID=<?php echo $data_artcile['ID_Articles']; ?>">Accepter l'Offre</a>
                    <br /><br />
                    <form method="post" action="Negocier_VendeurF.php?ID=<?php echo $data_artcile['ID_Articles']; ?>">
                        <label for="PrixNegocie" class="sr-only">Proposer un Prix</label>
                        <input class="form-control" type="number" min="0" max="<?php echo $data_offre['PrixInitial']; ?>" name="PrixNegocie" id="PrixNegocie" required autofocus />
                        <button type="submit" class="btn btn-primary" name="Negocier">Proposer un prix</button>
                    </form>
                    <br />
                    <a class="btn btn-danger btn-sm" href="abandonner_negocier_vendeur.php?ID=<?php echo $data_artcile['ID_Articles']; ?>">Annuler les Négociations</a>
<?php
                    }
                    else {
?>
                    <p>L'offre a été accepté.</p>
<?php
                    }
?>
                </div>
            </div>
            <br /><br /><br />
        </div>
        <footer>
            <div class="container-fluid">
                <p class="copyright">Droit d'auteur | Copyright &copy; 2021, Guillaume Corniglion, Tichique Luis, Sacha Mokotowitch</p>
                <p class="link">
                    <a href="index.php">Administrateur</a>
                </p>
            </div>
        </footer>
    </div>
</body>

</html>