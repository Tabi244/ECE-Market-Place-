<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="page_bienvenue.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}
		
        .card-img-top {
            width: 350px;
            height: 200px;
            background-position: center center;
        }
	</style>
</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/Logo.png" style="width:70px"/></a></h1><br><br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>         
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
<br><br><br><br>

</header>	

<div class="container">
    <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card">
                <img class="card-img-top" src="Images/enchere.jpg" alt="Enchères" title="Article afficher pour une durée fixée, libre à vous d'enchérir. Le plus ambitieux l'emporte.">
                <div class="card-img-overlay">
                    <h4 class="card-title">Meilleure offre</h4>
                    <a href="TypeAchatMeilleureO.php" class="btn btn-primary">Voir</a>
                </div>
       
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="card">
                        <img class="card-img-top" src="Images/transaction.jpg" alt="Meilleur offre">
                        <div class="card-img-overlay">
                            <h4 class="card-title">Transaction Vendeur-Client</h4>
                            <a href="TypeAchatNegociation.php" class="btn btn-primary">Voir</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="card">
                        <img class="card-img-top" src="Images/achat.png" alt="Achat">
                        <div class="card-img-overlay">
                            <h4 class="card-title">Achetez-le maintenant</h4>
                            <a href="TypeAchatImmediat.php" class="btn btn-primary">Voir</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>