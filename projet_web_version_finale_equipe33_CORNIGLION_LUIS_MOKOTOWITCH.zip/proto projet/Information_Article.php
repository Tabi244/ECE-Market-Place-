<?php
    session_start();
    header( 'content-type: text/html; charset=utf-8' );
    
    $id_A= isset($_GET["ID_Articles"])? $_GET["ID_Articles"] : "";
    $dateActuelle = date("Y-m-d", strtotime('+0 day', mktime(0, 0, 0, date('m'), date('d'), date('Y')))) . " " . date("H:i:s", strtotime('+2 hour'));

    
    $database = "ece_marketplace" ;

    
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    $sql = "SELECT * FROM articles WHERE ID_Articles = '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data_article = mysqli_fetch_assoc($result);
    
    $Email_Vendeur = $data_article['Email_vendeur'];
    
    $sql = "SELECT * FROM vendeur WHERE Email_vendeur = '$Email_Vendeur'";
    $result = mysqli_query($db_handle, $sql);
    $data_vendeur = mysqli_fetch_assoc($result);

    $sql = "SELECT * FROM encheres WHERE ID_Encheres= '$id_A'";
    $result = mysqli_query($db_handle, $sql);
    $data_enchere = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="page_bienvenue.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        .photo_item {
            height: 220px;
        }

        .style {
            text-decoration: underline;
            font-style: italic;
            font-size: 0.9rem;
        }
        table tr td {
            text-align: center;
        }
	.footer{
		background-color: #6699ff;
	    text-align: center;
    }
 
    .footer h6{
		padding: 10px;
    }
    </style>
</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/Logo.png" style="width:70px"/></a></h1><br><br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>   
		<li><a href="panier_acheteur.php">Panier</a></li>         
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>     
	</ul>
<br><br><br><br>

</header>	


        <div class="container">
            <?php
            if($data_article['TypeAchat'] == "Meilleure offre") {
            ?>
            <h2 align="center">Date de fin de l'enchère : <span style="color: #003d66; font-weight: bold;"><?php echo $data_enchere['DateFin']; ?></span></h2>
            <?php
            }
            ?>
            <div class="row border d-flex align-items-center">
                <div class="col-lg-4 col-md-4" align="center"><a href="images/Items/<?php echo $data_article['Photo_article']; ?>" target="_blank"><img class="photo_item" alt="photo de l'article" src="images/Items/<?php echo $data_article['Photo_article']; ?>" /></a></div>
                <div class="col-lg-6 col-md-6">
                    <table align="center">
                        <tr>
                            <td class="style">Numéro d'Identification</td>
                            <td><?php echo $data_article['ID_Articles']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Nom de l'Item</td>
                            <td><?php echo $data_article['Nom_article']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Nom du vendeur</td>
                            <td>
                                <?php
                                    if ($Email_Vendeur != "") {
                                        echo $data_vendeur['Nom_vendeur'] . " " . $data_vendeur['Prenom_vendeur'];
                                    }
                                    else {
                                        echo "Inconnu...";
                                    }
                                ?></td>
                        </tr>
                        <tr>
                            <td class="style">Catégorie</td>
                            <td><?php echo $data_article['Categorie']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Type d'Achat</td>
                            <td><?php echo $data_article['TypeAchat']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Qualité</td>
                            <td><?php echo $data_article['Qualite']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Défaut</td>
                            <td><?php echo $data_article['Defaut']; ?></td>
                        </tr>
                        <tr>
                            <td class="style">Prix</td>
                            <td><?php echo number_format($data_article['Prix'], 2, ',', ' '); ?>€</td>
                        </tr>
                    </table>
                </div>
                <div class="col-lg-2 col-md-2">
                    <?php
                        if(stristr($data_article['TypeAchat'], 'achat direct') == TRUE) { 
                    ?>
                    <form method="post" action="panier_acheteur.php?id_article=<?php echo $data_article['ID_Articles']; ?>">
                        <button type="submit" class="btn btn-success" name="achat_rapide">Ajouter au panier</button>
                    </form>
                    <?php
                        } 
                    ?>
                    
                    <?php
                        if(stristr($data_article['TypeAchat'], 'Transaction') == TRUE) { 
                    ?>
                    <form method="post" action="negociation.php?ID=<?php echo $data_article['ID_Articles']; ?>">
                        <button type="submit" class="btn btn-success" name="Negocier">Négocier</button>
                    </form>
                    <?php
                        } 
                    ?>
                    
                    <?php
                        if($data_article['TypeAchat'] == "Meilleure Offre") {
                            $dateFin = $data_enchere['DateFin'];
                            if($dateActuelle <= $dateFin) {
                    ?>
                    <form method="post" action="encheres.php?ID=<?php echo $data_article['ID_Articles']; ?>">
                        <label for="PrixEnchere" class="sr-only">Proposez un prix</label>
                        <input class="form-control" type="number" min="0" name="PrixEnchere" id="PrixEnchere" required autofocus />
                        <button type="submit" class="btn btn-success" name="Encheres">Faire une Offre</button>
                    </form>

<?php
                            }
                            else {
                                echo "<h6 align='center' style='color: #003d66; font-weight: bold;'>Les offres sont terminée.</h6><br />";
                                if($data_Encheres['Email_Acheteur'] == $_SESSION['Email_acheteur']) {
?>
                    <form method="post" action="panier_acheteur.php?id_article=<?php echo $data_article['ID_Articles']; ?>">
                        <button type="submit" class="btn btn-success" name="enchere">Ajouter au panier</button>
                    </form>
<?php
                                }
                            }
                        }
?>
                </div>
            </div>
            <br /><br /><br />
        </div>

<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur    </a> <a href="Connexion_vendeur.php">     Vendeur</a></h6>

</div>

</body>

</html>