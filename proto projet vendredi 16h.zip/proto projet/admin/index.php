<?php

	session_start();

	$user='Tabi244';
	$mdp='viveleprojetweb';

	if(isset($_POST['submit'])){
		$username=$_POST['username'];
		$password=$_POST['password'];
		
		if($username&&$password){
			echo'Connexion en cours... ';
			
			if($username==$user&&$password==$mdp){
				echo'Access granted';
				$SESSION['username']=$username;
				header('Location: admin.php');
				
			}else echo'Echec. Pseudo et/ou mot de passe invalides';
		}else echo'Veuillez remplir tout les champs';
	}
?>

<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<style>
		.logo{
			text-align: center;
			background-color: #6699ff;
		}
		
		.menu{
		     text-align: center;
        }
 
        .menu li{
	         display: inline;
		}
 
		.menu li a{
			 padding: 15px 80px;
			 background-color: #6699ff;
			 margin-right: 30px;
			 color: white;
		}
 
		.menu li a:hover{
			background-color: #5d42f5;
		}
	
		.titrecoadmin{
			text-align: center;
		}
		
		.formul{
			text-align: center;
		}
	</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="../index.php"><img src="../images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1><br/></br>
	<ul class="menu">
		<li><a href="../index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li>
		<li><a href="messages.php">Notifications</a></li>    
		<li><a href="panier.php">Panier</a></li>             
		<li><a href="login.php">Votre compte</a></li>       
	</ul>
</br></br>
</header>

<link href="admin/admin.css" rel="stylesheet" type="text/css"/>
<h1 class="titrecoadmin">Connexion-administrateur</h1>
<br><br>
<form class="formul" action="" method="POST">
	<h3>Pseudo : </h3><input type="text" name="username"/></br>
	<h3>Mot de passe : </h3><input type="password" name="password"/></br>
	</br><input type="submit" name="submit"/></br>
</form>



<style>
	 .footer{
		 background-color: #6699ff;
		 text-align: center;
     }

</style>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<div class="footer">
<h5> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h5>
<h5><a href="../admin/index.php">Administrateur</a></h5>

</div>
