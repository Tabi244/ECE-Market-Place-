






<!DOCTYPE html>
<html>

<head>
    <title>ECE MARKETPLACE - ADMINISTRATEUR</title>
    <meta charset="utf-8">
    <link rel="icon" href="../images/eceMarketPlaceLogo.png" />
    <link rel="stylesheet" type="text/css" href="style/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <style>
        .bouton {
            height: 150px;
            padding-top: 60px;
            background-color: #6699ff;
            font-size: 1.3em;
        }

        .bouton a {
            color: white;
        }

        .bouton a:hover {
            color: white;
            font-weight: bold;
        }
		
		.link{
			text-align: center;
		}
		
		.copyright{
			text-align: center;
			background-color: #6699ff;
			margin-left: 0px;
		}
		
		#titre{
			text-align: center;
			background-color: #6699ff;
			color: white;
			padding: 10px;
		}
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.formObj{
			text-align: center;
		}


    </style>
</head>

<body>

<header class="container-fluid">
    <div id="titre">
        <h1>Ajout d'un vendeur</h1>
    </div>
</header>
<br><br>
<h2 class="formObj">Veuillez remplir tous les champs</h2>
<br><br>

<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-lg-offset-4 col-md-offset-4 "></div>
        <div class="col-lg-4 col-md-4">
            <form class="form-signin" action="formajout_vendeur.php" method="post" enctype="multipart/form-data">
                <label for="ID_vendeur" class="sr-only">ID</label>
                <input type="number" id="ID_vendeur" name="ID_vendeur" class="form-control" placeholder="ID" required autofocus>
				
                <label for="Pseudo_vendeur" class="sr-only">Pseudo</label>
                <input type="text" id="Pseudo_vendeur" name="Pseudo_vendeur" class="form-control" placeholder="Pseudo" required>
				
                <label for="Prenom_vendeur" class="sr-only">Prenom</label>
                <input type="text" id="Prenom_vendeur" name="Prenom_vendeur" class="form-control" placeholder="Prenom" required>
			   
                <label for="Mdp_vendeur" class="sr-only">Mot de passe vendeur</label>
                <input type="password" id="Mdp_vendeur" name="Mdp_vendeur" class="form-control" placeholder="Mot de passe" required>
				
                <label for="Email_vendeur" class="sr-only">Email vendeur</label>
                <input type="email" id="Email_vendeur" name="Email_vendeur" class="form-control" placeholder="Email" required>
				
                <label for="Photo_vendeur">Photo de Profil</label>
                <input type="file" name="Photo_vendeur" class="form-control">
				
                <label for="image_Fond">couverture</label>
                <input type="file" name="image_Fond" class="form-control">
                        <br /><br />
						
                <tr colspan="2" align="center">
                    <td>
                        <button class="btn btn-lg btn-primary btn-block" name="btn_vendeur" type="submit">Ajouter vendeur</button>
                    </td>
                </tr>
            </form>
        </div>
        <div class="col-lg-offset-4 col-md-offset-4"></div>
    </div>
</div>


</body>


<br><br><br><br><br><br><br>
<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin.php">Administrateur    </a> <a href="../deconnexion.php">     Déconnexion</a></h6>

</div>

</html>