<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<style>
		.footer{
			background-color: #6699ff;
			text-align: center;
		}
 
		.footer h6{
			padding: 10px;
		}
		
		.ti{
			text-align: center;
		}
		
		.profil{
			text-align: center;
		}

</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1></br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="magasin.php">Tout parcourir</a></li> 
		<li><a href="messages.php">Notifications</a></li>  
		<li><a href="panier_acheteur.php">Panier</a></li>       
		<li><a href="moncompte_acheteur.php">Votre compte</a></li>    
	</ul>
</br></br>
	<div id="titre">
        <h1 class="profil">Profil acheteur - guillaume "guiguideparis"</h1>
    </div>

</header>
<br><br>
<body>
    <div id="contenu">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8 col-md-8 profil" align="center">
                    <table align="center" class="table">
                        <tr>
                            <td class="style">Pseudo</td>
                            <td>guiguideparis</td>
                        </tr>

                        <tr>
                            <td class="style">Prénom</td>
                            <td>Guillaume</td>
                        </tr>
						
                        <tr>
                            <td class="style">Numéro de Téléphone</td>
                            <td>0625108555</td>
                        </tr>
						
                        <tr>
                            <td> </td>
                            <td> </td>
                        </tr>
                        <tr>
                            <td class="style">Adresse</td>
                            <td>6 rue des lilas</td>
                        </tr>
						
                        <tr>
                            <td class="style">Code Postal</td>
                            <td>75007</td>
                        </tr>
						
                        <tr>
                            <td class="style">Ville</td>
                            <td>Paris</td>
                        </tr>
						
                        <tr>
                            <td class="style">Pays</td>
                            <td>France</td>
                        </tr>
						
                        <tr>
                            <td> </td>
                            <td> </td>
                        </tr>
                        <tr>
                            <td class="style">Numéro de Carte Bancaire</td>
                            <td>1111111111</td>
                        </tr>
                    </table>
                </div>
                <div class="col-lg-offset-1 col-md-offset-1"></div>
                <div class="col-lg-3 col-md-3 align-self-center">
                    <br /><br />
                    <div class="bouton border d-flex justify-content-around"><a href="liste_nego_acheteur.php">Voir mes négociations</a></div>
                </div>
            </div>
        </div>
    </div>




</body>


<br><br><br>
<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur</a></h6>

</div>