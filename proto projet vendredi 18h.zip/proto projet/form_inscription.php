<?php
    session_start();
    
    header( 'content-type: text/html; charset=utf-8' );
    
    //Récupération des données venant de la page d'Inscription
    $ID_acheteur = isset($_POST["ID_acheteur"])? $_POST["ID_acheteur"] : "";
    $Mdp_acheteur = isset($_POST["Mdp_acheteur"])? $_POST["Mdp_acheteur"] : "";
    $Prenom_acheteur = isset($_POST["Prenom_acheteur"])? $_POST["Prenom_acheteur"] : "";
    $Adresse = isset($_POST["Adresse"])? $_POST["Adresse"] : "";
    $CodePostal = isset($_POST["CodePostal"])? $_POST["CodePostal"] : "";
    $Ville = isset($_POST["Ville"])? $_POST["Ville"] : "";
    $Pays = isset($_POST["Pays"])? $_POST["Pays"] : "";
    $Email_acheteur = isset($_POST["Email_acheteur"])? $_POST["Email_acheteur"] : "";
    $Telephone = isset($_POST["Telephone"])? $_POST["Telephone"] : "";
    $NumeroCarte = isset($_POST["NumeroCarte"])? $_POST["NumeroCarte"] : "";
    $Pseudo_acheteur = isset($_POST["Pseudo_acheteur"])? $_POST["Pseudo_acheteur"] : "";

    //Identification de notre BDD
    $database = "ece_marketplace" ;

    //Connexion dans notre BDD
    //Rappel : Votre serveur = localhost | votre login = root | votre MDP = '' (rien)
    $db_handle = mysqli_connect('localhost', 'root', '');
    $db_found = mysqli_select_db($db_handle, $database) ;
    
    //Si le bouton "Envoyer" est cliqué
    if (isset($_POST["btn_inscription"])) {
        //Si la BDD existe
        if ($db_found) {
            $sql = "SELECT * FROM acheteur WHERE Email = '$Email'";
            $result = mysqli_query($db_handle, $sql);
            
            //Si l'Email est déjà dans la table Acheteur
            if (mysqli_num_rows($result) != 0) {
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css"/>
	<style>
	.footer{
		 background-color: #6699ff;
		 text-align: center;
    }
 
    .footer h6{
	     padding: 10px;
    }
	
	.t{
		text-align: center;
	}

	</style>

</head>

<header>
	<h1 class="logo">ECE MarketPlace  <a href="index.php"><img src="images/eceMarketPlaceLogo.png" style="width:70px"/></a></h1></br></br>
	<ul class="menu">
		<li><a href="index.php">Accueil</a></li>
		<li><a href="inscription.php">Tout parcourir</a></li> 
		<li><a href="inscription.php">Notifications</a></li>    
		<li><a href="inscription.php">Panier</a></li>             
		<li><a href="inscription.php">Votre compte</a></li>     
	</ul>
</br></br>
<h1 class="t">Inscription - Acheteur</h1><br>
</header>

<div id="contenu">
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-lg-offset-4 col-md-offset-4 "></div>
				<div class="col-lg-4 col-md-4">
                    <form class="form-signin" action="form_inscription.php" method="post">
                        <label for="ID" class="sr-only">ID</label>
                        <input type="number" id="ID_acheteur" name="ID_acheteur" class="form-control" placeholder="ID" required autofocus>
						
                        <label for="Mdp_acheteur" class="sr-only">Mot de Passe</label>
                        <input type="password" id="Mdp_acheteur" name="Mdp_acheteur" class="form-control" placeholder="Mot de Passe" required>
						
                        <label for="Prenom_acheteur" class="sr-only">Prenom</label>
                        <input type="text" id="Prenom_acheteur" name="Prenom_acheteur" class="form-control" placeholder="Prenom" required>
						
                        <label for="Adresse" class="sr-only">Adresse</label>
                        <input type="text" id="Adresse" name="Adresse" class="form-control" placeholder="Adresse" required>
						
                        <label for="CodePostal" class="sr-only">Code Postal</label>
                        <input type="number" id="CodePostal" name="CodePostal" class="form-control" placeholder="CodePostal" required>
						
                        <label for="Ville" class="sr-only">Ville</label>
                        <input type="text" id="Ville" name="Ville" class="form-control" placeholder="Ville" required>
						
                        <label for="Pays" class="sr-only">Pays</label>
                        <input type="text" id="Pays" name="Pays" class="form-control" placeholder="Pays" required>
						
                        <label for="Email_acheteur" class="sr-only">Email</label>
                        <input type="email" id="Email_acheteur" name="Email_acheteur" class="form-control" placeholder="Email" required>
						
                        <label for="Telephone" class="sr-only">Telephone</label>
                        <input type="number" id="Telephone" name="Telephone" class="form-control" placeholder="Telephone" required>
						
                        <label for="NumeroCarte" class="sr-only">Numéro de CB</label>
                        <input type="text" id="NumeroCarte" name="NumeroCarte" class="form-control" placeholder="Numéro de CB" required>
						
                        
                        <label for="Pseudo_acheteur" class="sr-only">Pseudo</label>
                        <input type="text" id="Pseudo_acheteur" name="Pseudo_acheteur" class="form-control" placeholder="Pseudo" required>
                        <br />
                        <tr colspan="2" align="center">
                            <td>
                                <button class="btn btn-lg btn-primary btn-block" name="btn_inscription" type="submit">Envoyer</button>
                            </td>
                        </tr>
                    </form>
            </div>
        <div class="col-lg-offset-4 col-md-offset-4"></div>
    </div>
</div>

<br>
<div class="footer">
<h6> Copyright &copy; ECE MarketPlace 2021 | Guillaume CORNIGLION, Tichique LUIS, Sacha MOKOTOWITCH </h6>
<a href="mailto:ece-marketplace@contact.fr"> Contactez-nous ! </a>
<h6><a href="admin/index.php">Administrateur</a></h6>

</div>

</html>

<?php
            }
            
            //Si l'Email n'est pas dans la table Acheteur
            else {
                $sql = "INSERT INTO acheteur(ID_acheteur, Mdp_acheteur, Prenom_acheteur, Adresse, CodePostal, Ville, Pays, Email_acheteur, Telephone, NumeroCarte, Pseudo_acheteur) VALUES('$ID_acheteur', '$Mdp_acheteur', '$Prenom_acheteur', '$Adresse', '$CodePostal', '$Ville', '$Pays', '$Email_acheteur', '$Telephone', '$NumeroCarte', '$Pseudo_acheteur')";
                $result = mysqli_query($db_handle, $sql);
                header('Location: bienvenue.php');
                exit();
            }
        }
        //Si la BDD n'existe pas
        else {
            echo "<strong>Database not found</strong>";
        }
    }

    //Fermer la connexion
    mysqli_close($db_handle);
?>